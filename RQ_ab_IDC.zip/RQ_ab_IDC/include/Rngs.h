/******************************************************************\
 * File:           Rngs.h for rng
 * Language:       C++ (ISO 1998)
 * Copyright:      Jiheng Zhang, Georgia Institute of Technology
 * Date:           13 July 2007
\******************************************************************/

#ifndef RNGS_H_
#define RNGS_H_

#include "RngBase.h"
#include <queue>
#include <vector>

// ===================== Uniform =====================
//! Continuous uniform random number generator. 
/**
 * Generates random numbers according to Uniform([l,u])
 */
class UniformGen: public RngBase
{
public:
	//! Default constructor.
	UniformGen(){};
	UniformGen(double l, double u);
	//! Function that generates next random number.
	virtual double genNext();
	//! Get the \f$n\f$th moment of the distribution.
	virtual double getMoment(int n) const;
	
protected:
	double lower, upper;
};

// ===================== Exponential =====================
//! Exponential random number generator. 
/**
 * Generates random numbers according to Exponential distribution with parameter
 *  \f$\lambda\f$. 
 * The distribution function is \f$1-\exp(-\lambda x)\f$.
 */
class ExpGen: public RngBase
{
public:
	//! Default constructor.
	ExpGen(){};
	//! Standard constructor which sets standard parameter \f$\lambda=a\f$.
	ExpGen(double a);
	//! Non-standard constructor which sets not-standard parameter.
	/**
	 * \param ch : a char specifying the way to construct.
	 * \param m : mean
	 */	
	ExpGen(char ch, double m);
	//! Function that generates next random number.
	virtual double genNext();
	//! Get the \f$n\f$th moment of the distribution.
	virtual double getMoment(int n) const;
	
protected:
	double lambda;
};

// ===================== Deterministic =====================
//! Deterministic. 
/**
 * There is nothing special, it just produce the same specified number.
 */
class DetGen: public RngBase
{
public:
	//! Constructor.
	DetGen(double a);
	//! Function that generates next random number.
	virtual double genNext();
	//! Get the \f$n\f$th moment of the distribution.
	virtual double getMoment(int n) const;
};

// ===================== Hyper Exponential /2 phase =====================
//! Hyper Exponential with 2 phase random number generator. 
/**
 * Generates random numbers according to 2 phase Hyper Exponential distribution 
 * standard parameters \f$\alpha, \beta, p\f$. 
 * The distribution function is \f$1-p\exp(-\alpha x)-(1-p)\exp(-\beta x)\f$.
 */
class HyperExp2Gen: public RngBase
{
public:
	//! Default constructor.
	HyperExp2Gen(){};
	//! Standard constructor which sets standard parameters \f$\alpha=a,\beta=b,p=p\f$.
	HyperExp2Gen(double a, double b, double p);
	//! Non-standard constructor which sets non-standard parameters.
	/**
	 * \paran ch : a char specifying the way to construct.
	 * \param m : mean;
	 * \param coe : coefficient of variation;
	 * \param rat : ratio \f$rat=\frac{1-p}{\beta}:\frac{p}{\alpha}\f$.
	 */	
	HyperExp2Gen(char ch, double m, double coe, double rat);
	//! Function that generates next random number.
	virtual double genNext();
	//! Get the \f$n\f$th moment of the distribution.
	virtual double getMoment(int n) const;
	
protected:
	double alpha,beta,p;
	double r;
};

// ===================== Hyper2Star =====================
//! Hyper* 2 phase random number generator. 
/**
 * Generates random numbers according to Hyper* 2 phase distribution with standard 
 * parameters \f$\mu\f$ and \f$p\f$. 
 * The distribution function is \f$1-p\exp(-\mu x)\f$.
 */
class Hyper2StarGen: public RngBase
{
public:
	//! Default constructor.
	Hyper2StarGen(){};
	//! Constructor which sets standard parameters \f$\mu=mu,p=p\f$.
	Hyper2StarGen(double mu, double p);
	//! Construct generator from non-standard parameters.
	/**
	 * \paran ch : a char specifying the way to construct.
	 * \param m : mean;
	 * \param coe : coefficient of variation.
	 */	
	Hyper2StarGen(char ch, double m, double coe);
	//! Function that generates next random number.
	virtual double genNext();
	//! Get the \f$n\f$th moment of the distribution.
	virtual double getMoment(int n) const;
	
protected:
	double mu,p;

};

// ===================== Erlang =====================
//! Erlang random number generator. 
/**
 * Generates random numbers according to Erlang distribution with standard 
 * parameters \f$\mu\f$ and \f$p\f$. 
 * The distribution function is \f$\gamma(k, \lambda x)/(k-1)!\f$, 
 * where \f$\gamma(\cdot,\cdot)\f$ is the lower incomplete gamma function.
 */
class ErlangGen: public RngBase
{
public:
	//! Default constructor.
	ErlangGen(){};
	//! Constructor which sets standard parameters \f$\lambda=a\f$ and phase number \f$k=n\f$.
	ErlangGen(double a, int n);
	//! Construct generator from non-standard parameters.
	/**
	 * \paran ch : a char specifying the way to construct.
	 * \param m : mean;
	 * \param n : phase number.
	 */	
	ErlangGen(char ch, double m, int n);
	//! Function that generates next random number.
	virtual double genNext();
	//! Get the \f$n\f$th moment of the distribution.
	virtual double getMoment(int n) const;
	
protected:
	double lambda, k;

};

// ===================== Bimodal =====================
//! Bimodal random number generator. 
/**
 * Generates random numbers with probability \f$p\f$ to be a constant \f$a\f$, 
 * and with probability  \f$1-p\f$ to be \f$0\f$.
 */
class BimodalGen: public RngBase
{
public:
	//! Default constructor.
	BimodalGen(){};
	//! Constructor which sets standard parameter \f$\lambda=a\f$.
	BimodalGen(double a, double p);
	//! Construct generator from non-standard parameter.
	/**
	 * \paran ch : a char specifying the way to construct.
	 * \param m : mean;
	 * \param m : cv.
	 */	
	BimodalGen(char ch, double m, double coe);
	//! Function that generates next random number.
	virtual double genNext();
	//! Get the \f$n\f$th moment of the distribution.
	virtual double getMoment(int n) const;
	
protected:
	double a, p;
};

// ===================== Normal =====================
//! Normal random number generator. 
/**
 * Generates random numbers according to Normal distribution with mean
 *  \f$\mu\f$ and variance \f$\sigma^2\f$. 
 */
class NormalGen: public RngBase
{
public:
	//! Default constructor.
	NormalGen(){};
	//! Standard constructor sets \f$\mu=\_mean\f$ and \f$\sigma^2=\_var\f$.
	NormalGen(double _mean, double _var);
	//! Non-standard constructor which sets not-standard parameter.
	/**
	 * \param ch : a char specifying the way to construct.
	 * \param _mean : mean
	 * \param _cv : coefficient of variation
	 */	
	NormalGen(char ch, double _mean, double _cv);	
	//! Function that generates next random number.
	
	virtual double genNext();
	//! Get the third moment of the distribution.
	virtual double getMoment(int n) const;
	
	//! Restart the generator from the begining.
	void restart();
	//! Reset the generator, to the beginning of the substream.
	void restartSub();
	//! Start the generator from the beginning of the next substream.
	void startNextSub();
	
	double getSdv(){ return sdv; }
	
protected:
	double sdv;
	double z2;

};


// ===================== Log-Normal =====================
//! Log-Normal random number generator. 
/**
 * Generates random numbers according to Log-Normal distribution with mean
 *  \f$\mu\f$ and variance \f$\sigma^2\f$. 
 */
class LogNormalGen: public NormalGen
{
public:
	//! Default constructor.
	LogNormalGen(){};
	//! Standard constructor sets \f$\mu=\_mean\f$ and \f$\sigma^2=\_var\f$.
	LogNormalGen(double _mean, double _var);
	
	//! Non-standard constructor which sets not-standard parameter.
	/**
	 * \param ch : a char specifying the way to construct.
	 * \param _mu : mean of the normal part
	 * \param _sigma2 : variance of normal part
	 */	
	LogNormalGen(char ch, double _mu, double _sigma2);	
	
	//! Function that generates next random number.
	virtual double genNext();

	double getMean() const { return a_mean; }

	double getVar() const { return a_var; }

	double getCV() const { return a_cv; }

	//! Get the \f$n\f$th moment of the distribution.
	virtual double getMoment(int n) const;
	
protected:
	double a_mean, a_var, a_cv;

};


// ===================== Discrete =====================
//! discrete random number generator. 
/**
 * Generates random numbers a discrete distribution with parameter p1,...,pn.
 */
class DiscreteGen: public RngBase
{
public:
	//! Standard constructor which sets standard parameter \f$\lambda=a\f$.
	DiscreteGen(int n, double *p);
	DiscreteGen(int n, double *p, int *val);
	//! Function that generates next random number.
	virtual double genNext();
	//! Get the \f$n\f$th moment of the distribution.
	virtual double getMoment(int n) const;
	
protected:
	double *pmf;
	int *values;
	int length;
};



// ===================== Superposition =====================
//! SuperpositionGen random number generator. 
/**
 * Generates Superposition process
 */
class SuperpositionGen: public RngBase
{
public:
	//! Standard constructor which sets standard parameter \f$\lambda=a\f$.
	SuperpositionGen(int n, RngBase *component);
	//! Function that generates next random number.
	virtual double genNext();
	//! Get the \f$n\f$th moment of the distribution.
	virtual double getMoment(int n) const;
	
protected:
	int numComponent;
	RngBase *genComponent;
	double currTime, prevTime;
	std::priority_queue<double, std::vector<double>, std::greater<double> > events;

};



// ===================== MMPP(2) =====================

class MMPP2Gen: public RngBase
{
public:
	//! Standard constructor.
	MMPP2Gen(double a12, double a21, double l1, double l2);
	//! Function that generates next random number.
	virtual double genNext();
	//! Get the \f$n\f$th moment of the distribution.
	virtual double getMoment(int n) const;
	
protected:
	double alpha12, alpha21, lambda1, lambda2;
	bool state;
	double currTime, prevTime;

};



// ===================== MAP =====================

class MapGen: public RngBase
{
public:
	//! Standard constructor.
	MapGen(int n_states, double **D0, double **D1);
	//! Function that generates next random number.
	virtual double genNext();
	//! Get the \f$n\f$th moment of the distribution.
	virtual double getMoment(int n) const;
	
protected:
	double **D_0;
	double **D_1;
	int num_states;

	int state, nextState;
	double currTime, prevTime;

	DiscreteGen **eventGen;	
	double **prob;
	std::vector<double> rateStateChange;

};


// ===================== Gamma =====================
//! Gamma random number generator. 
/**
 * Generates random numbers according to Gamma distribution with shape \alpha
 *  rate \beta.
 */
class GammaGen: public RngBase
{
public:
	//! Default constructor.
	GammaGen(){};
	//! Standard constructor sets using shape and rate.
	GammaGen(double _alpha, double _beta);
	//! Non-standard constructor which sets not-standard parameter shape and scale.
	/**
	 * \param ch : a char specifying the way to construct.
	 * \param _k : shape
	 * \param _theta : scale
	 */	
	GammaGen(char ch, double _k, double _theta);	
	//! Function that generates next random number.
	
	virtual double genNext();
	//! Get the third moment of the distribution.
	virtual double getMoment(int n) const;
	
	//! Restart the generator from the begining.
	void restart();
	//! Reset the generator, to the beginning of the substream.
	void restartSub();
	//! Start the generator from the beginning of the next substream.
	void startNextSub();
	
	double getSdv(){ return sdv; }
	
protected:
	double alpha;
	double beta;
	bool flag_alpha_less_than_1;
	double sdv;
	double lambda, w, r;

};


// ===================== Hawkes_exp =====================
//! Generate interarrival time of the Hawkes process with exponential excitation. 
/**
* 	Parameters:
* 	lambda_0 - Starting intensity
* 	nu - background intensity
*	lambda_plus - intensity right after arrival
*	lambda_minus - intensity right before arrival
* 	alpha - Amount intensity increases after an arrival
* 	beta - Decay of intensity over time
*	Reference: Exact simulation of Hawkes process with exponentially decaying intensity 2013
 */
class HawkesExpGen: public RngBase
{
public:
	//! Standard constructor which sets standard parameter \f$\lambda=a\f$.
	HawkesExpGen(double bg_nu, double alp, double bet);
	//! Function that generates next random number.
	virtual double genNext();
	//! Get the \f$n\f$th moment of the distribution.
	virtual double getMoment(int n) const;
	
protected:
	double nu, lambda_plus, lambda_minus, alpha, beta;
	double D, S;
};


// ===================== XSqGen =====================
//! Generate interarrival time of the x^2 CDF

class XSqGen: public RngBase
{
public:
	//! Standard constructor which sets standard parameter \f$\lambda=a\f$.
	XSqGen(double rate);
	//! Function that generates next random number.
	virtual double genNext();
	//! Get the \f$n\f$th moment of the distribution.
	virtual double getMoment(int n) const;
	
protected:
	double lambda;
};

#endif /*RNGS_H_*/
