/******************************************************************\
 * File:           Customer.h for OQN
 * Language:       C++ (ISO 1998)
 * Copyright:      Wei You, Columbia University
 * Date:           4 April 2014
\******************************************************************/

#ifndef CUSTOMER_H_
#define CUSTOMER_H_

class Customer
{
protected: 
	double arrivalTime, serviceTime, waitTime, accuWaitTime;
	double patienceTime;
	
	int nodeID;
	
	bool isInSystem, isInQueue, isInService;
		
public:
	Customer (int id) {
		waitTime = 0;
		accuWaitTime = 0;
		patienceTime = 0;
		nodeID = id;
		isInSystem = true;
		isInQueue = false;
		isInService = false;	
	}

	virtual ~Customer(){};

 	void joinQueue (int id) {
		isInQueue = true;
		isInService = false;
		nodeID = id;
	}
	
	void startService (double t, int id) {
		waitTime = t - arrivalTime;
		accuWaitTime += waitTime;
		isInQueue = false;		
		isInService = true;	
		nodeID = id;
	}
	
	void depart () {
		nodeID = -1;
		waitTime = 0;
		isInSystem = true;
		isInQueue = false;
		isInService = false;	
	}
	
	void departSystem () {
		isInSystem = false;
	}
	
	void setArrivalTime(double aTime) {
		arrivalTime = aTime;
	}
	
	void setServiceTime(double sTime) {
		serviceTime = sTime;
	}

	void setPatienceTime(double pTime) {
		patienceTime = pTime;
	}
	
	void resetWaitTime() {
		waitTime = 0;
	}
	
	double getServiceTime () {
		return serviceTime;
	}
	
	double getPatienceTime () {
		return patienceTime;
	}

	double getWaitTime () {
		return waitTime;
	}
	
};

#endif /*CUSTOMER_H_*/
