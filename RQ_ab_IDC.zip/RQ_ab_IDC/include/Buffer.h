/******************************************************************\
 * File:           Event.h for OQN
 * Language:       C++ (ISO 1998)
 * Copyright:      Wei You, Columbia University
 * Date:           4 April 2014
\******************************************************************/

#ifndef BUFFER_H_
#define BUFFER_H_

#include <queue>
#include "Customer.h"

class buffer{
public:
	buffer(){};
	virtual ~buffer(){};

	void initBuffer()  { while(!q.empty()) q.pop(); }

	void inQueue(Customer *c)  { q.push(c); }
	void deQueue( ) { q.pop(); }
	void abandonCust(Customer *c){
		queue<Customer *>::iterator it=q.begin();
		while ( it!=q.end() )
		{
			if ( (*it)->getTimeToAbd()!= c->getTimeToAbd() )
				it++;
			else 
				break;
		}
		if ( it==q.end() )
		{
			printf("Abandon Error! No customer found!\n");
			exit(-1);
		}
		delete (*it);
		it=q.erase(it);
//		printf("Customer Abandon!\n");
	}

	Customer *getQueueHead() { return q.front(); }
	int getQueueSize() { return q.size(); }
	bool checkEmpty() { return q.empty(); }

private:
		std::queue<Customer*> q;  //build a buffer using STL queue
};
#endif