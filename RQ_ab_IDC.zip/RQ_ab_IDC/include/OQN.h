/******************************************************************\
 * File:           OQN.h for single node queueing system
 * Language:       C++ (ISO 1998)
 * Copyright:      Wei You, Columbia University
 * Date:           4 April 2016
\******************************************************************/

#ifndef OQN_H_
#define OQN_H_

#include "Node.h"
#include "Customer.h"
#include "Event.h"
#include "Rngs.h"
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cmath>
#include <math.h>
#include <vector>
#include <algorithm>
#include <queue>
#include <string>

using namespace std;

class OQN {

	public:
	OQN ( ) { };
	OQN (int nodesNum, int *serverNum, double **mat, int extArrNum, int *IDextArr, RngBase **arrDist, RngBase **servDist, RngBase **patDist, double tDiscard) ;
	virtual ~OQN ( ) { };
	
	void genIntArrEvent (int id, double arr_time, Customer *c);
	void genExtArrEvent (int id, double arr_time);
	void genDepartEvent (int id, double serv_start_time, Customer *c);
	void updateWorkload (double simT, int sID, double nextServTime);
	Event nextEvent ();
	void actOn (Event Ev);
	void calcIDC (string name);
	void calcIDW (string name);
	void calcVar (string name,double abd);
	void calcIDC_Palm (double rho);
	
	double getClock()   { return t; }

//get statistic information
	double MeanWaitTime(int id) {return nodes[id].getMeanWaitTime(); }
	double numDeparted(int id) {return nodes[id].getNumDeparted(); }
	double getAccuWorkload(int id) {return accuWorkload[id];}
	double getCustAvgWorkload(int id) {return custAccuWL[id]/counter[id];}
	double getRenegeRate(int id) {return (double) counter_ab[id]/counter[id];}
	std::vector<double> getArrSeq() {return arrToLastQ;}

protected:
	
	double t;  // system clocks
	int numNodes; 
	Node *nodes;
	double **routingMat;

	double timeDiscard;

	int *extArrID; int numExtArr;
	RngBase **extArrGen, **servGen, **patGen, **routingGen;

	Event *newEv;

	std::priority_queue<Event*, deque<Event*>, eventCompareT> eventsToCome;  

	// statistical data
	double *workload, *accuWorkload, *custAccuWL, *lastArrT;
	long *counter, *counter_ab;
	std::vector<double> arrToLastQ;
	std::vector<double> arrActual;
	std::vector<double> serviceTimes;
	std::vector<double> wlRecord;

};

#endif