from multiprocessing import Pool
import numpy as np
from scipy.stats import norm
from matplotlib import pyplot as plt
import time

def w_star(t):
    return ((t**2 + 2*t - 1)*(1 - 2*(1-norm.cdf(np.sqrt(t)))) + 2*norm.pdf(np.sqrt(t))*np.sqrt(t)*(1+t) - t**2)/2/t

def ROU(T,dt):
    f0 = 1;
    c = -1;
    c2_a = 1;
    c2_s = 0.5;

    t = np.arange(0,T,dt) 

    x0 = norm.rvs(c/f0,np.sqrt((c2_a + c2_s)/2/f0))
    while x0<0:
        x0 = norm.rvs(c/f0,np.sqrt((c2_a + c2_s)/2/f0))

    B_s = np.zeros(len(t))
    L = np.zeros(len(t))
    x = np.zeros(len(t))
    x[0] = x0
    for i in range(len(t)-1):
        d_s = np.sqrt(c2_s)*np.sqrt(dt)*norm.rvs(0,1)
        d_a = np.sqrt(c2_a)*np.sqrt(dt)*norm.rvs(0,1)
        B_s[i+1] = B_s[i] + d_s
        L[i+1] = L[i] - np.minimum(0,x[i] + (c - f0*x[i])*dt + d_s + d_a)
        x[i+1] = np.maximum(0,x[i] + (c - f0*x[i])*dt + d_s + d_a)

    return x - B_s - L - x[0]

def Calc_var():
    val = np.array([])
    N = 3000
    T = 20
    dN = 1000
    dt = 1/dN
    for i in range(N):
        val = np.append(val, ROU(T,dt))
        print(str(i) + "/" + str(N))
    val = val.reshape(N,int(T*dN))

    return [np.arange(dt,T+dt,dt), np.var(val.T,axis = 1)/np.arange(dt,T+dt,dt)]


if __name__ == '__main__':
    
    start = time.time()
    
    num_proc = 8
    pool = Pool(processes=num_proc) 

    result_a = [pool.apply_async(Calc_var, args=()) for i in range(num_proc)]
    results = [r.get() for r in result_a]
    res = np.mean(results, axis=0)
    
    plt.plot(res[0],res[1],res[0],(1-w_star(res[0]))*1 + w_star(res[0])*0.6)
    plt.xscale('log')

    end = time.time()
    print(end - start)

    np.savetxt("./Data/var_-1_1_0.5.txt", np.array(res).transpose(), delimiter="\t")
    
    plt.savefig('IDC_-1_1_0.5.eps', bbox_inches='tight')
    plt.show()
    