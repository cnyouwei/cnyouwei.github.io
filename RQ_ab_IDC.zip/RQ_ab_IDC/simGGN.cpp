/******************************************************************\
 * File:           simGGN.cpp for simulating single node queueing system
 * Language:       C++ (ISO 1998)
 * Copyright:      Wei You, Columbia University
 * Date:           4 April 2016
\******************************************************************/

#include <fstream>
#include <iostream>
#include <iomanip>
#include <time.h>
#include <vector>
#include <tgmath.h>
#include "Rngs.h"
#include "OQN.h"
#include <thread>
#include <numeric>

#define NUM_THREADS 1

using namespace std;

vector<double> val_cust,val_syst,renege_rate;

double sample_mean (const vector<double> &values) {
	
	double oldM, newM;
	double oldV, newV, summand;
    oldM = newM = 0.0;
    oldV = newV = 0.0;

    long n = 1;
    for ( auto const& v: values) {
    	newV = v;
    	summand = newV - oldV;
    	newM = oldM + (summand - oldM)/n;
        oldM = newM; 
        oldV = newV;
        n += 1;
    }

	return newM;
}

void sim_thread(double lam_id, double abd_id) {
	double simTime = 1400000000/lam_id; 
	//double simTime = 170000000/lam_id;
	double timeDiscard = 0;
	
	// int startTime = time(NULL);

	/*   ------ Model Specification -----  */

	unsigned int numNodes = 1;
	int *numServer = new int[numNodes];
	for(unsigned int i = 0; i < numNodes; i++ ) {numServer[i] = 1;}

	RngBase **arr, **serv, **pat;

	arr = new RngBase*[numNodes];
	int extArrID[1] = {0};
	int numExtArr = 1;
	serv = new RngBase*[numNodes];
	pat = new RngBase*[numNodes];

	double **mat = new double*[numNodes];
	
	for (unsigned int i = 0; i < numNodes; i++) {
		mat[i] = new double[numNodes];
		for (unsigned int j = 0; j < numNodes; j++) {
			mat[i][j] = 0;
		}
	}

	// QIS
	for (unsigned int i = 0; i < numNodes-1; i++) {
		mat[i][i+1] = 1;
	}

	/*   -------------------------------  */

	double SCV_H2 = 4;
	double ratio = 0.5;
	double b = - (SCV_H2 + 1.0)/2 - ratio*ratio + (1-ratio)*(1-ratio);
	double p_H2 = ( - b + sqrt(b*b - 2*(SCV_H2 + 1)*ratio*ratio))/(SCV_H2 + 1);
	double mu1_H2 = p_H2/ratio;		
	double mu2_H2 = (1-p_H2)/(1-ratio);		

	double SCV2_H2 = 4;
	double ratio2 = 0.5;
	double b2 = - (SCV2_H2 + 1.0)/2 - ratio2*ratio2 + (1-ratio2)*(1-ratio2);
	double p2_H2 = ( - b2 + sqrt(b2*b2 - 2*(SCV2_H2 + 1)*ratio2*ratio2))/(SCV2_H2 + 1);
	double mu12_H2 = p2_H2/ratio2;		
	double mu22_H2 = (1-p2_H2)/(1-ratio2);		
	// double rho = tid;
	// double alpha = 0.5;
	// double beta = 1;

	arr[0] = new HyperExp2Gen(mu1_H2*lam_id,mu2_H2*lam_id,p_H2); // ExpGen(lam_id); // ErlangGen(2*lam_id,2); // HyperExp2Gen(mu1_H2*lam_id,mu2_H2*lam_id,p_H2); // HawkesExpGen(1.0 - alpha/beta,alpha,beta);
	serv[0] = new ExpGen(1); // HyperExp2Gen(mu12_H2,mu22_H2,p2_H2); //  ErlangGen(2,2); // LogNormalGen(1,4); // ExpGen(mu_id);  
	pat[0] = new XSqGen(abd_id); //ErlangGen(2*abd_id,2); // ExpGen(abd_id); // HyperExp2Gen(mu1_H2*abd_id,mu2_H2*abd_id,p_H2); // HyperExp2Gen(mu1_H2*abd_id,mu2_H2*abd_id,p_H2); //LogNormalGen(1/abd_id,2/abd_id/abd_id); //
	
	/*   ------ Start Simulation  -----  */

	cout<<std::to_string(lam_id)<<endl;
	
	OQN myQueue(numNodes,numServer,mat,numExtArr,extArrID,arr,serv,pat,timeDiscard);
	Event event;

	while( myQueue.getClock() < simTime ){
		event = myQueue.nextEvent ( );
		myQueue.actOn(event);
	}
				
	// ofstream writeWorkload;
	// writeWorkload.open("./Data/test.txt",ios::app);

	double sys_WL = myQueue.getAccuWorkload(0)/(simTime - timeDiscard);//*2*(1-rho)/(rho*rho);
	double cus_WL = myQueue.getCustAvgWorkload(0);//*2*(1-rho)/(rho*rho);
	double rene = myQueue.getRenegeRate(0);
	// cout<<sys_WL<<"\t"<<cus_WL<<"\t"<<cus_WL - sys_WL<<"\t"<<(time(NULL)-startTime)/60<<" min "<<(time(NULL)-startTime)%60<<" seconds."<<endl;
	// cout<<myQueue.getRenegeRate(0)<<endl;

	val_cust.push_back(cus_WL);
	val_syst.push_back(sys_WL);
	renege_rate.push_back(rene);

	//double normalizedWL, normalizedWT;
	//normalizedWL = myQueue.getAccuWorkload(numNodes-1)/(simTime - timeDiscard)*2*(1-rho)/(rho*rho);
	//normalizedWT = myQueue.MeanWaitTime(numNodes-1)*2*(1-rho)/(rho*rho);
	//writeWorkload<<rho<<"\t"<<normalizedWL<<"\t"<<normalizedWT<<"\n";

	// cout<<normalizedWL<<"\t"<<normalizedWT<<"\t"<<(time(NULL)-startTime)/60<<" min "<<(time(NULL)-startTime)%60<<" seconds."<<endl;
	
	// writeWorkload.close(); 

	// cout<<(time(NULL)-startTime)/60<<" min "<<(time(NULL)-startTime)%60<<" seconds."<<endl;

	double sa_mean = sample_mean(myQueue.getArrSeq());
	cout<<sa_mean<<endl;

	myQueue.calcVar("./Data/var_M_H4_E2_" + std::to_string(lam_id) + "_2048.txt",abd_id);

}


int main() {

	int startTime = time(NULL);

	std::thread t[NUM_THREADS];


	vector<double> c = {-5. , -4.5, -4. , -3.5, -3. , -2.5, -2. , -1.5, -1. , -0.5,  0. ,
        0.5,  1. ,  1.5,  2. ,  2.5,  3. ,  3.5,  4. ,  4.5,  5. };	
   	//vector<double> lam_rates = {1.5,2,2.5,3};
	//double lam = 0.95;	
	//vector<double> abd_rates = {16.,   64.,  144.,  256.,  400.,  576.,  784., 1024., 1296., 1600., 1936., 2304., 2704., 3136., 3600., 4096., 4624., 5184., 5776., 6400., 7056., 7744., 8464., 9216.};
    vector<double> abd_rates = {2048};
    double abd = abd_rates[0];
    vector<double> lam_rates(c.size());
    for(int i = 0; i < c.size(); i++) {
    	lam_rates[i] = 1-c[i]*pow(1.0/abd,2.0/3.0);
    	cout<<lam_rates[i]<<"\t";
    }
    	 
    double WL = 0.0;
	double WL_cust = 0.0;
	double renege_r = 0.0;

	for (auto lam: lam_rates) {
		
		for (int i = 0; i < NUM_THREADS; ++i) {
			t[i] = std::thread(sim_thread, lam, 1.0/abd);
		}
					
		for (int i = 0; i < NUM_THREADS; ++i) {
			t[i].join();
		}

		WL = 0.0;
		WL_cust = 0.0;
		renege_r = 0.0;
		for (int i = 0; i < NUM_THREADS; ++i) {
			WL += val_syst.at(i);
			WL_cust += val_cust.at(i);
			renege_r += renege_rate.at(i);
		}
			
		WL /= NUM_THREADS;
		WL_cust /= NUM_THREADS;
		renege_r /= NUM_THREADS;


		cout<< std::fixed<<std::setprecision(5)<<lam<<"\t"<<1/abd<<"\t"<<std::setprecision(4)<<WL<<"\t"<<renege_r<<endl;


		cout<<(time(NULL)-startTime)/60<<" min "<<(time(NULL)-startTime)%60<<" seconds."<<endl;
	}

	return 0;

}
