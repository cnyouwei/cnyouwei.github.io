/******************************************************************\
 * File:           OQN.cpp for single node queueing system
 * Language:       C++ (ISO 1998)
 * Copyright:      Wei You, Columbia University
 * Date:           4 April 2016
\******************************************************************/

#include "OQN.h"

OQN::OQN (int nodesNum, int *serverNum, double **mat, int extArrNum, int *IDextArr, RngBase **arrDist, RngBase **servDist, RngBase **patDist, double tDiscard = 0) {
	
	t = 0; numNodes = nodesNum; routingMat = mat;

 	nodes = new Node[numNodes];
 	servGen = new RngBase*[numNodes];
 	patGen = new RngBase*[numNodes];
 	routingGen = new RngBase*[numNodes];
 	workload = new double[numNodes];
 	accuWorkload = new double[numNodes];
 	custAccuWL = new double[numNodes];
 	lastArrT = new double[numNodes];
	counter = new long[numNodes];
	counter_ab = new long[numNodes];

 	for (int i = 0; i < numNodes; i++) {
 		nodes[i].initNode(i, serverNum[i]);
 		servGen[i] = servDist[i];
 		patGen[i] = patDist[i];
 		routingGen[i] = new DiscreteGen(numNodes,routingMat[i]);
 		workload[i] = 0.0;
 		accuWorkload[i] = 0.0;
		custAccuWL[i] = 0.0;
 		lastArrT[i] = 0.0;
		counter[i] = 0;
		counter_ab[i] = 0;
 	}

	extArrID = IDextArr;  numExtArr = extArrNum;
 	extArrGen = new RngBase*[numExtArr];

 	for (int i = 0; i < numExtArr; i++) {
 		extArrGen[i] = arrDist[i];
 		// Generate first customers
 		genExtArrEvent( extArrID[i], extArrGen[i]->genNext() );
 	}

 	timeDiscard = tDiscard;

 	//writeArrToLastQ.open("./Data/ArrT.txt");

 }

void OQN::genIntArrEvent (int id, double arr_time, Customer *c) { 
	newEv = new Event(arr_time, id, intArrival);
	newEv->customer = c;
	eventsToCome.push(newEv);
}

void OQN::genExtArrEvent (int id, double arr_time) {  
	newEv = new Event(arr_time, id, extArrival);
	newEv->customer = new Customer(id);
	eventsToCome.push(newEv);
}

void OQN::genDepartEvent (int id, double serv_start_time, Customer *c) {
	newEv = new Event(serv_start_time + c->getServiceTime(), id, departure);
	newEv->customer = c;
	eventsToCome.push(newEv);
}

void OQN::updateWorkload (double simT, int ID, double nextServTime) {		
	double interArrT = simT - lastArrT[ID];
	//printf("interArrT is: %f. nextServiceT is: %f\n",interArrT, nextServTime);

	if (nodes[ID].checkEmpty()) {
		if (simT > timeDiscard) {
			accuWorkload[ID] = accuWorkload[ID] + workload[ID]*workload[ID]/2;
		}
	} else {
		if (simT > timeDiscard) {
			accuWorkload[ID] = accuWorkload[ID] + workload[ID]*interArrT - interArrT*interArrT/2;
		}
	}

	workload[ID] = max(workload[ID] - interArrT,0.0) + nextServTime;
	lastArrT[ID] = simT;
}

void OQN::actOn(Event Ev)
{
	t = Ev.timeToMaturity;	

    if (Ev.type == extArrival || Ev.type == intArrival ){        // case 1: arrival
    	Ev.customer->setArrivalTime(t);
    	double nextPatT = patGen[Ev.location]->genNext();
		Ev.customer->setPatienceTime(nextPatT);
    	updateWorkload(t, Ev.location, 0);
		custAccuWL[Ev.location] += workload[Ev.location];
		counter[Ev.location] += 1;
		
		if (Ev.location == 0 && t > 100000) {
			arrActual.push_back(t-100000);
			wlRecord.push_back(workload[Ev.location]);
		}   		
		
		if (Ev.customer->getPatienceTime() >= workload[Ev.location]) {
    		double nextServT = servGen[Ev.location]->genNext();
    		//printf("nextServiceT is: %f\n",nextServT);
    		Ev.customer->setServiceTime(nextServT);

			workload[Ev.location] += nextServT;

			if ( nodes[Ev.location].checkVacancy() ) {
				nodes[Ev.location].admitCust(t, Ev.customer);
				genDepartEvent(Ev.location,t,Ev.customer);
			}
			else {
				nodes[Ev.location].putInQueue(Ev.customer);
    		}

			if (Ev.location == 0 && t > 100000) {
				arrToLastQ.push_back(t-100000);
				serviceTimes.push_back(nextServT);
			}   
		} else {
			delete Ev.customer;
			counter_ab[Ev.location] += 1;
		}

    	if (Ev.type == extArrival) {   // If external, schedule next arrival
    		genExtArrEvent( Ev.location, extArrGen[0]->genNext() + Ev.timeToMaturity);
    	}



    } else if (Ev.type == departure) { // case 2: departure

		nodes[Ev.location].deptCust(t,Ev.customer);
		int nextLoc;
		nextLoc = routingGen[Ev.location]->genNext();
		if (nextLoc != -1) {
			genIntArrEvent( nextLoc, t, Ev.customer);
		} else if (nextLoc == -1) {
			delete Ev.customer;
		}

		//If queue is not empty, let the front enter node

		if (nodes[Ev.location].getQueueSize() > 0){
			Customer *c = nodes[Ev.location].popNextInQueue();
   			nodes[Ev.location].admitCust(t, c);
			genDepartEvent(Ev.location,t,c);
		}

		//if (Ev.location == 0 && t > 10000000) {
    	//	arrToLastQ.push_back(t-10000000);
    		//serviceTimes.push_back(nextServT);
		//}   
		
    } else if (Ev.type == reneging){
    	
    } else {
    	cerr<<"something wrong: what is the type of next event?"<<endl;
    } 

}


Event OQN::nextEvent()
{
	Event *Eve = eventsToCome.top();
	Event Ev = *Eve;
	eventsToCome.pop();
	delete Eve;
	return Ev;
}


double sample_Var (const vector<double> &values) {
	
	double oldM, newM, S;
    oldM = newM = S = 0.0;

    long n = 1;
    for ( auto const& v: values) {
    	newM = oldM + (v - oldM)/n;
        S += (v - oldM)*(v - newM);            
        oldM = newM; 
        n += 1;
    }

	return S/(n-1);
}


double sample_Mean (const vector<double> &values) {
	
	double mean = 0.0;

    long n = 1;
    for ( auto const& v: values) {
    	mean += v;
        n += 1;
    }

	return mean/n;
}



void smallIntervals (double delta, int start_power2, int end_power2, int maxCounterSize_power2, vector<vector<double>> &results, const vector<double> &ArrT) {
	
	double init_step_power2 = start_power2 - delta;
	double maxT = pow(2, maxCounterSize_power2 + init_step_power2);
	vector<double> counters(pow(2,maxCounterSize_power2));

	double init_step = pow(2,init_step_power2);
	for ( auto const& t: ArrT) {
		if(t<maxT) {
			++counters[floor(t/init_step)];
		}
	}

	int offset = 1;

	while ( offset <= pow(2, end_power2 - start_power2) ) {

		vector<double> temp = {init_step*offset, sample_Var(counters)/(init_step*offset), sample_Mean(counters)/(init_step*offset)};
		results.push_back(temp);

		for (auto iter = counters.begin(); iter != counters.end() - offset; ++iter) {
			*iter += *(iter + offset);
		}

		for (int i = 0; i < offset; ++i) { 
			counters.pop_back();
		}

		offset *= 2;
	}

	return;
}

void largeIntervals (double delta, int start_power2, vector<vector<double>> &results, const vector<double> &ArrT) {

	double init_step_power2 = start_power2 - delta;

 	double lastT_power2 = floor(log2(ArrT.back())-init_step_power2) + init_step_power2;
	double relativeHorizen_power2 = 16 - start_power2;
	int numInterval_power2 = lastT_power2 - init_step_power2;
	double maxT = pow(2, lastT_power2);

	vector<double> counters(pow(2,numInterval_power2));

	double init_step = pow(2,init_step_power2);
	for ( auto const& t: ArrT) {
		if(t<maxT) {
			++counters[floor(t/init_step)];
		}
	}

	int offset = 1;

	while ( offset <= pow(2,relativeHorizen_power2) ) {

		vector<double> temp = {init_step*offset, sample_Var(counters)/(init_step*offset), sample_Mean(counters)/(init_step*offset)};
		results.push_back(temp);

		for (auto iter = counters.begin(); iter != counters.end() - offset; ++iter) {
			*iter += *(iter + offset);
		}

		for (int i = 0; i < offset; ++i) { 
			counters.pop_back();
		}

		offset *= 2;
	}

	return;

}

void smallIntervals_var (double delta, int start_power2, int end_power2, int maxCounterSize_power2, vector<vector<double>> &results, 
						 const vector<double> &ArrT, const vector<double> &ServT, const vector<double> &arrActual, const vector<double> &wlRecord, double abd) {
	
	double init_step_power2 = start_power2 - delta;
	double maxT = pow(2, maxCounterSize_power2 + init_step_power2);
	vector<double> counters(pow(2,maxCounterSize_power2));
	vector<double> counters2(pow(2,maxCounterSize_power2));
	vector<double> counters3(pow(2,maxCounterSize_power2));

	double init_step = pow(2,init_step_power2);
	for ( unsigned int t = 0; t<ArrT.size(); t++) {
		if(ArrT[t]<maxT) {
			counters[floor(ArrT[t]/init_step)] += ServT[t];
		} else {
			break;
		}
	}
	for ( unsigned int t = 0; t<arrActual.size(); t++) {
		if(arrActual[t]<maxT) {
			counters2[floor(arrActual[t]/init_step)] += exp(-abd*wlRecord[t]);
			counters3[floor(arrActual[t]/init_step)] += exp(-abd*wlRecord[t])*exp(-abd*wlRecord[t]);
		}
	}

	int offset = 1;

	while ( offset <= pow(2, end_power2 - start_power2) ) {

		vector<double> temp = {init_step*offset, 
							   sample_Var(counters), sample_Mean(counters),
							   sample_Var(counters2), sample_Mean(counters2),
							   sample_Var(counters3), sample_Mean(counters3)};
		results.push_back(temp);

		for (auto iter = counters.begin(); iter != counters.end() - offset; ++iter) {
			*iter += *(iter + offset);
		}
		for (auto iter = counters2.begin(); iter != counters2.end() - offset; ++iter) {
			*iter += *(iter + offset);
		}
		for (auto iter = counters3.begin(); iter != counters3.end() - offset; ++iter) {
			*iter += *(iter + offset);
		}

		for (int i = 0; i < offset; ++i) { 
			counters.pop_back();
			counters2.pop_back();
			counters3.pop_back();
		}


		offset *= 2;
	}

	return;
}

void largeIntervals_var (double delta, int start_power2, vector<vector<double>> &results, 
						 const vector<double> &ArrT, const vector<double> &ServT, const vector<double> &arrActual, const vector<double> &wlRecord, double abd) {

	double init_step_power2 = start_power2 - delta;

 	double lastT_power2 = floor(log2(ArrT.back())-init_step_power2) + init_step_power2;
	double relativeHorizen_power2 = 16 - start_power2;
	int numInterval_power2 = lastT_power2 - init_step_power2;
	double maxT = pow(2, lastT_power2);

	vector<double> counters(pow(2,numInterval_power2));
	vector<double> counters2(pow(2,numInterval_power2));
	vector<double> counters3(pow(2,numInterval_power2));

	double init_step = pow(2,init_step_power2);
	for ( unsigned int t = 0; t<ArrT.size(); t++) {
		if(ArrT[t]<maxT) {
			counters[floor(ArrT[t]/init_step)] += ServT[t];
		} else {
			break;
		}
	}
	for ( unsigned int t = 0; t<arrActual.size(); t++) {
		if(arrActual[t]<maxT) {
			counters2[floor(arrActual[t]/init_step)] += exp(-abd*wlRecord[t]);
			counters3[floor(arrActual[t]/init_step)] += exp(-abd*wlRecord[t])*exp(-abd*wlRecord[t]);
		}
	}

	int offset = 1;

	while ( offset <= pow(2,relativeHorizen_power2) ) {

		vector<double> temp = {init_step*offset, 
							   sample_Var(counters), sample_Mean(counters),
							   sample_Var(counters2), sample_Mean(counters2),
							   sample_Var(counters3), sample_Mean(counters3)};		
		results.push_back(temp);

		for (auto iter = counters.begin(); iter != counters.end() - offset; ++iter) {
			*iter += *(iter + offset);
		}
		for (auto iter = counters2.begin(); iter != counters2.end() - offset; ++iter) {
			*iter += *(iter + offset);
		}
		for (auto iter = counters3.begin(); iter != counters3.end() - offset; ++iter) {
			*iter += *(iter + offset);
		}

		for (int i = 0; i < offset; ++i) { 
			counters.pop_back();
			counters2.pop_back();
			counters3.pop_back();
		}

		offset *= 2;
	}

	return;

}


void smallIntervals_IDW (double delta, int start_power2, int end_power2, int maxCounterSize_power2, vector<vector<double>> &results, const vector<double> &ArrT, const vector<double> &servTs) {
	
	double init_step_power2 = start_power2 - delta;
	double maxT = pow(2, maxCounterSize_power2 + init_step_power2);
	vector<double> counters(pow(2,maxCounterSize_power2));

	double init_step = pow(2,init_step_power2);

	for ( unsigned long ind = 0; ind < ArrT.size(); ind++) {
		if(ArrT[ind]<maxT) {
			counters[floor(ArrT[ind]/init_step)] += servTs[ind];
		} else {
			break;
		}
	}

	int offset = 1;

	while ( offset <= pow(2, end_power2 - start_power2) ) {

		vector<double> temp = {init_step*offset, sample_Var(counters)/(init_step*offset)};
		results.push_back(temp);

		for (auto iter = counters.begin(); iter != counters.end() - offset; ++iter) {
			*iter += *(iter + offset);
		}

		for (int i = 0; i < offset; ++i) { 
			counters.pop_back();
		}

		offset *= 2;
	}

	return;
}

void largeIntervals_IDW (double delta, int start_power2, vector<vector<double>> &results, const vector<double> &ArrT, const vector<double> &servTs) {

	double init_step_power2 = start_power2 - delta;

 	double lastT_power2 = floor(log2(ArrT.back())-init_step_power2) + init_step_power2;
	double relativeHorizen_power2 = 20 - start_power2;
	int numInterval_power2 = lastT_power2 - init_step_power2;
	double maxT = pow(2, lastT_power2);

	vector<double> counters(pow(2,numInterval_power2));

	double init_step = pow(2,init_step_power2);

	for ( unsigned long ind = 0; ind < ArrT.size(); ind++) {
		if(ArrT[ind]<maxT) {
			counters[floor(ArrT[ind]/init_step)] += servTs[ind];
		} else {
			break;
		}
	}

	int offset = 1;

	while ( offset <= pow(2,relativeHorizen_power2) ) {

		vector<double> temp = {init_step*offset, sample_Var(counters)/(init_step*offset)};
		results.push_back(temp);

		for (auto iter = counters.begin(); iter != counters.end() - offset; ++iter) {
			*iter += *(iter + offset);
		}

		for (int i = 0; i < offset; ++i) { 
			counters.pop_back();
		}

		offset *= 2;
	}

	return;

}

void OQN::calcIDC(string name) 
{
	vector<vector<double>> results;	
	
	cout<<"Calculating IDC...  ";
	for (int i = 0; i < 10; i += 1) {
		cout<<i*10<<"% => "<<std::flush;
    	smallIntervals(i/10.0,-10,-5,29,results,arrToLastQ);	
    	smallIntervals(i/10.0,-4,-3,28,results,arrToLastQ);	
    	smallIntervals(i/10.0,-2,0,28,results,arrToLastQ);	
    	smallIntervals(i/10.0,1,4,28,results,arrToLastQ);	
 		largeIntervals(i/10.0,5,results,arrToLastQ);
	}
	cout<<"100%\n"<<std::flush;
	
    std::sort( results.begin(), results.end() );

	ofstream fileWriter (name);

	for( auto const& point: results ) {
        for( auto const& x: point ) fileWriter << x << '\t';
        fileWriter<<endl;
    }

    fileWriter.close();
}

void OQN::calcVar(string name, double abd) 
{
	vector<vector<double>> results;	
	
	int reps = 5;
	cout<<"Calculating IDC...  ";
	for (int i = 0; i < reps; i += 1) {
		cout<<i*(100/reps)<<"% => "<<std::flush;
    	smallIntervals_var(i*1.0/reps,-4,-3,25,results,arrToLastQ,serviceTimes,arrActual,wlRecord,abd);	
    	smallIntervals_var(i*1.0/reps,-2,0,25,results,arrToLastQ,serviceTimes,arrActual,wlRecord,abd);	
    	smallIntervals_var(i*1.0/reps,1,4,25,results,arrToLastQ,serviceTimes,arrActual,wlRecord,abd);	
		largeIntervals_var(i*1.0/reps,5,results,arrToLastQ,serviceTimes,arrActual,wlRecord,abd);
	}
	cout<<"100%\n"<<std::flush;
	
    std::sort( results.begin(), results.end() );

	ofstream fileWriter (name);

	for( auto const& point: results ) {
        for( auto const& x: point ) fileWriter << x <<'\t';
        fileWriter<<endl;
    }

    fileWriter.close();
}


void OQN::calcIDW(string name) 
{
	vector<vector<double>> results;	
	
	//cout<<"Calculating IDC...  ";
	for (int i = 0; i < 10; i += 1) {
		//cout<<i*10<<"% => "<<std::flush;
    	smallIntervals_IDW(i/10.0,-10,-8,27,results,arrToLastQ, serviceTimes);	
    	smallIntervals_IDW(i/10.0,-7,-5,27,results,arrToLastQ, serviceTimes);	
    	smallIntervals_IDW(i/10.0,-4,-3,27,results,arrToLastQ, serviceTimes);	
    	smallIntervals_IDW(i/10.0,-2,0,27,results,arrToLastQ, serviceTimes);	
    	smallIntervals_IDW(i/10.0,1,4,27,results,arrToLastQ, serviceTimes);	
 		largeIntervals_IDW(i/10.0,5,results,arrToLastQ, serviceTimes);
	}
	//cout<<"100%"<<std::flush;
	
    std::sort( results.begin(), results.end() );

	ofstream fileWriter (name);

	for( auto const& point: results ) {
        for( auto const& x: point ) fileWriter << x << '\t';
        fileWriter<<endl;
    }

    fileWriter.close();

}
