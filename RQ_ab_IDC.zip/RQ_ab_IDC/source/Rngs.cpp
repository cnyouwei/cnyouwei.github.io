/******************************************************************\
 * File:           Rngs.cpp for rng
 * Language:       C++ (ISO 1998)
 * Copyright:      Jiheng Zhang, Georgia Institute of Technology
 * Date:           March 4, 2010
\******************************************************************/

#include <math.h>
#include <cstdlib>
#include <iostream>
#include <limits>
#include "Rngs.h"
using namespace std;

double MAX_double = numeric_limits<double>::max();

// ===================== Uniform =====================
UniformGen::UniformGen(double l, double u)
{
	if (l >= u) {
		cerr<<"Lower bound higher than upper bound.\n";
		exit(-1);
	}
	lower = l;
	upper = u;
	mean=(l+u)/2;
	name="Uniform";	
	cv=(u-l)*(u-l)/12/mean/mean;
	var=(u-l)*(u-l)/12;
}

double UniformGen::genNext()
{
	return stream.RandU01()*(upper-lower) + lower;
}

double UniformGen::getMoment(int n) const
{
	return	-1;
}

// ===================== Exponential =====================
ExpGen::ExpGen(double a)
{
	if (a<= 0){
		cerr<<"Exponential parameter error: check lambda>0\n";
		exit(-1);
	}
	lambda=a;
	mean=1.0/a;
	name="Exponential";	
	cv=1;
	var=mean*mean;
}

ExpGen::ExpGen(char ch, double m)
{
	if (ch!='N') cerr<<"Please specify a way to construct!\n";
	if (m<= 0){
		cerr<<"Exponential parameter error: check lambda>0\n";
		exit(-1);
	}
	lambda=1.0/m;
	mean=m;
	name="Exponential";	
	cv=1;
	var=mean*mean;
}

double ExpGen::genNext()
{
	return -log(stream.RandU01())/lambda;
}

double ExpGen::getMoment(int n) const
{
	double temp=1;
	for (int i=n;i>0;i--) temp*=(mean*i);
	return	temp;
}

// ===================== Deterministic =====================
DetGen::DetGen(double a)
{
	name="Deterministic";	
	mean=a;
	cv=0;
	var=0;
}

double DetGen::genNext()
{
	return mean;
}

double DetGen::getMoment(int n) const
{
	return	pow(mean, 3);
}

// ===================== Hyper Exponential /2 phase =====================
HyperExp2Gen::HyperExp2Gen(double a, double b, double q)
{
	if (a<= 0||b<=0||q<0||q>1){
		cerr<<"HyperExp2 parameter error: check a,b >0, q in [0,1]\n";
		exit(-1);
	}
	alpha=a;
	beta=b;
	p=q;
	name="HyperExp2phase";	
	mean=p/alpha+(1.0-p)/beta;
	cv=2*( p/(alpha*alpha)+(1.0-p)/(beta*beta) )/(mean*mean)-1;
	var=mean*mean*cv;
}

HyperExp2Gen::HyperExp2Gen(char ch, double m, double coe, double rat)
{
	if (ch!='N') cerr<<"Please specify a way to construct!\n";
	if (m<= 0||coe<=0||rat<0){
		cerr<<"HyperExp2 parameter error: mean, scv >0, ratio>0\n";
		exit(-1);
	}
	mean=m;
	cv=coe;
	r=rat; //=(1-p)/beta:p/alpha
	       //r-->\infty ==> p-->2/cv+1, 3rdM--> a lower bound
	       //r-->\infty ==> p-->0,   3rdM--> infinity
	name="HyperExp2phase";
			
	double a=(cv+1)*(1+r)*(1+r);
	double b=2.0*(r*r-1)-a;
	double Delta=b*b-4*a*2.0;// c=2
	if(Delta<0) {
		cerr<<"Invalid Parameters for HyperExp2Gen!\n";
		exit(-1);
	}
	double delta=sqrt(Delta);

	p=(-b-delta)/(2.0*a);
	alpha=p*(1+r)/mean;
	beta=(1-p)*(1+r)/(r*mean);
	var=mean*mean*cv;
}

double HyperExp2Gen::genNext()
{
	if (stream.RandU01()<p)
		return -log(stream.RandU01())/alpha;
	else
		return -log(stream.RandU01())/beta;
}

double HyperExp2Gen::getMoment(int n) const
{
	double temp1=1, temp2=1;
	for(int i=n; i>0; i--){
		temp1*=(i/alpha);
		temp2*=(i/beta);
	}
	
	return	temp1*p+temp2*(1-p);
}

// ===================== Hyper2Star =====================
Hyper2StarGen::Hyper2StarGen(double u, double q)
{
	if (u<= 0||q<0||q>1){
		cerr<<"Hyper2Star parameter error: check u >0, q in [0,1]\n";
		exit(-1);
	}
	mu=u;
	p=q;
	name="Hyper2Star";	
	mean=p/mu;
	cv=2.0/p-1;
	var=mean*mean*cv;
}

Hyper2StarGen::Hyper2StarGen(char ch, double m, double coe)
{
	if (ch!='N') cerr<<"Please specify a way to construct!\n";
	if (m<= 0||coe<=0){
		cerr<<"Hyper2Star parameter error: mean, scv >0, ratio>0\n";
		exit(-1);
	}
	mean=m;
	cv=coe;
	name="Hyper2Star";	
	p=2.0/(cv+1);
	mu=p/mean;
	var=mean*mean*cv;
}

double Hyper2StarGen::genNext()
{
	if (stream.RandU01()<p)
		return -log(stream.RandU01())/mu;
	else
		return 0;
}

double Hyper2StarGen::getMoment(int n) const
{
	double temp=1;
	for(int i=n; i>0; i--) temp*=(double(i)/mu);
	return	p*temp;
}

// ===================== Erlang =====================
ErlangGen::ErlangGen(double a, int n)
{
	if (a<= 0||n<=0){
		cerr<<"Erlang parameter error: check lambda >0, n> 0";
		exit(-1);
	}
	lambda=a;
	k=n;
	name="Erlang";	
	
	mean=k/lambda;
	cv=1.0/k;
	var=mean*mean*cv;
}

ErlangGen::ErlangGen(char ch, double m, int n)
{
	if (ch!='N') cerr<<"Please specify a way to construct!\n";
	if (m<= 0||n<=0){
		cerr<<"Erlang parameter error: check lambda >0, n> 0";
		exit(-1);
	}
	mean=m;
	k=n;
	name="Erlang";
	
	lambda=k/m;
	cv=1.0/k;
	var=mean*mean*cv;
}

double ErlangGen::genNext()
{
	double z=0;
	for (int i=0;i<k;i++)
		z+=-log(stream.RandU01())/lambda;
	return z;
}

double ErlangGen::getMoment(int n) const
{
	double temp=1;
	for (int i=0; i<n; i++) temp*=(double(k+i)/lambda);
	return	temp;
}

// ===================== Bimodal =====================
BimodalGen::BimodalGen(double _a, double _p)
{
	if (_p<=0||_p>1){
		cerr<<"Bimodal parameters error: p in[0,1]\n";
		exit(-1);
	}
	a=_a;
	p=_p;
	name="Bimodal";
	mean=a*p;	
	cv=1.0/p-1.0;
	var=mean*mean*cv;
}

BimodalGen::BimodalGen(char ch, double m, double coe)
{
	if (ch!='N') cerr<<"Please specify a way to construct!\n";
	if (coe<= 0){
		cerr<<"Bimodal parameters error: check lambda>0\n";
		exit(-1);
	}
	mean=m;
	cv=coe;
	var=mean*mean*cv;
	name="Bimodal";	
	a=(1+cv)*mean;
	p=mean/a;
}

double BimodalGen::genNext()
{
	return (stream.RandU01()<p)? a: 0;
}

double BimodalGen::getMoment(int n) const
{
	return	p*pow(a,n);
}

// ===================== Normal =====================
NormalGen::NormalGen(double _mean, double _var)
{
	if (_var<= 0){
		cerr<<"Normal parameter error: check variance>0\n"; cerr<<_mean<<" "<<_var;
		exit(-1);
	}
	var=_var;
	sdv=sqrt(_var);
	mean=_mean;
	name="Normal";	
	if (mean!=0)
		cv=_var/(mean*mean);
	else
		cv=MAX_double;
	z2=0;
}

NormalGen::NormalGen(char ch, double _mean, double _cv)
{
	if (ch!='N') cerr<<"Please specify a way to construct!\n";
	if (cv<= 0){
		cerr<<"Normal parameter error: check cv>0\n";
		exit(-1);
	}
	mean=_mean;
	name="Normal";
	sdv=mean*sqrt(_cv);
	z2=0;
}

double NormalGen::genNext()
{
	double x,y,z1,s;
	
	if (z2!=0.0)		/* use value from previous call */
	{
		z1=z2;
		z2=0.0;
	}
	else{
		do {
			x=2.0*stream.RandU01()-1.0;
			y=2.0*stream.RandU01()-1.0;
			s=x*x+y*y;
		} while (s>=1.0);
		s=sqrt((-2.0*log(s))/s);
		z1=x*s;
		z2=y*s;
	}
	return mean+z1*sdv;
}

double NormalGen::getMoment(int n) const
{
	return	0;
}


void NormalGen::restart() {  stream.ResetStartStream(); z2=0; }

void NormalGen::restartSub() {  stream.ResetStartSubstream(); z2=0; }

void NormalGen::startNextSub() {  stream.ResetNextSubstream(); z2=0; }

// ===================== Log-Normal =====================

LogNormalGen::LogNormalGen(double _mean, double _var)
{
	if (_var<= 0){
		cerr<<"LogNormal parameter error: check variance>0\n";
		exit(-1);
	}
	a_var=_var;
	a_mean=_mean;
	name="LogNormal";	
	if (a_mean!=0)
		a_cv=a_var/(a_mean*a_mean);
	else
		cerr<<"LogNormal parameter error: check mean>0\n";
	
	double t_var=log(1+a_cv);
	double t_mean=log(a_mean)-0.5*t_var;

	if (t_var<= 0){
			cerr<<"Normal parameter error: check variance>0\n"; 
			exit(-1);
		}
	var=t_var;
	sdv=sqrt(var);
	mean=t_mean;
	if (mean!=0)
		cv=var/(mean*mean);
	else
		cv=MAX_double;
	z2=0;

}

LogNormalGen::LogNormalGen(char ch, double _mu, double _sigma2)
{
	if (ch!='N') cerr<<"Please specify a way to construct!\n";
	if (cv<= 0){
		cerr<<"LogNormal parameter error: check sigma^2>0\n";
		exit(-1);
	}
	
	if (_sigma2<= 0){
			cerr<<"Normal parameter error: check variance>0\n"; 
			exit(-1);
		}
	var=_sigma2;
	sdv=sqrt(var);
	mean=_mu;
	if (mean!=0)
		cv=var/(mean*mean);
	else
		cv=MAX_double;
	z2=0;
	
	name="LogNormal";	

	a_mean=exp(mean+var/2.0);
	a_var=a_mean*a_mean*(exp(var-1));
	a_cv=a_var/(a_mean*a_mean);
	

}

double LogNormalGen::genNext()
{
	double temp=NormalGen::genNext();
	return exp(temp);
}

double LogNormalGen::getMoment(int n) const
{
	return	exp(n*mean+double(n*n)*var/2.0);
}


// ===================== Discrete =====================
DiscreteGen::DiscreteGen(int n, double *p)
{
	length = n;
	pmf = p;
	values = new int[length];
	for(int i = 0; i < length; i++) {
		values[i] = i;
	}

	mean = 0;
	for (int i=0; i < length;i++) {
		mean+=values[i]*pmf[i];
	}
	name = "Distrete";	
}

DiscreteGen::DiscreteGen(int n, double *p, int *val)
{
	length = n;
	pmf = p;
	values = val;
	mean = 0;
	for (int i=0; i < length;i++) {
		mean+=values[i]*pmf[i];
	}
	name = "Distrete";	
}

double DiscreteGen::genNext()
{
	double u, cdf;
	u = stream.RandU01(), cdf = 0;
	for (int i = 0; i<length; i++) {
		cdf += pmf[i];
		if (u <= cdf) {
			return values[i];
		}
	}
	return -1;  
}

double DiscreteGen::getMoment(int n) const
{
	double temp=0;
	for (int i=0; i < length;i++) {
		temp+=pow(values[i], n)*pmf[i];
	}
	return	temp;
}


// ===================== SuperpositionGen =====================
SuperpositionGen::SuperpositionGen(int n, RngBase *component) 
{
    numComponent = n;
    genComponent = component;  
    currTime = 0;
    prevTime = 0;
    for (int i=0; i<numComponent; i++) {
    	events.push(genComponent->genNext());
    }
}

double SuperpositionGen::genNext()
{
	prevTime = currTime;
    currTime = events.top(); events.pop();
    events.push(currTime + genComponent->genNext());
    return currTime - prevTime;
}

double SuperpositionGen::getMoment(int n) const
{
	return	0;
}



// ===================== MMPP(2) =====================

MMPP2Gen::MMPP2Gen(double a12, double a21, double l1, double l2) {
	alpha12 = a12;
	alpha21 = a21;
	lambda1 = l1;
	lambda2 = l2;
	state = false;
	currTime = 0.0;
	prevTime = 0.0;

}


double MMPP2Gen::genNext()
{
	prevTime = currTime; 
	while (1) {
		if (state == false) {
			currTime += -log(stream.RandU01())/(alpha12 + lambda1);
			if (stream.RandU01() < (alpha12/(alpha12+lambda1))) {
				state = true;
				continue;
			} else {
				return currTime - prevTime;
			}
		} else {
			currTime += -log(stream.RandU01())/(alpha21 + lambda2);
			if (stream.RandU01() < (alpha21/(alpha21+lambda2))) {
				state = false;
				continue;
			} else {
				return currTime - prevTime;
			}
		}
	}
}

double MMPP2Gen::getMoment(int n) const
{
	return	0;
}

// ===================== MAP =====================

MapGen::MapGen(int n_states, double **D0, double **D1) {
	
	num_states = n_states;
	D_0 = new double*[num_states];
	D_1 = new double*[num_states];

	eventGen = new DiscreteGen*[num_states];
	prob = new double*[num_states];
	double accuP;

	for (int i = 0; i < num_states; i++) {
		D_0[i] = new double[num_states];
		D_1[i] = new double[num_states];

		accuP = 0.0;
		prob[i] = new double[num_states*2];
		for (int j = 0; j < num_states; j++) {
			D_0[i][j] = D0[i][j];
			D_1[i][j] = D1[i][j];
			accuP += D_1[i][j];
			accuP += D_0[i][j];
		}
		accuP -= D_0[i][i];
		rateStateChange.push_back(accuP);
		for (int j = 0; j < num_states; j++) {
			prob[i][j] = D0[i][j]/accuP;
		}
		for (int j = 0; j < num_states; j++) {
			prob[i][j+num_states] = D1[i][j]/accuP;
		}
		prob[i][i] = 0.0;
		eventGen[i] = new DiscreteGen(num_states*2,prob[i]);
	}

	state = 0;
	nextState = 0;
	currTime = 0.0;
	prevTime = 0.0;

}


double MapGen::genNext()
{
	prevTime = currTime; 
	while (1) {
		currTime += -log(stream.RandU01())/(rateStateChange[state]);
		
		nextState = eventGen[state]->genNext();

		if(nextState < num_states) {
			state = nextState;
			continue;
		} else {
			state = nextState - num_states;
			return currTime - prevTime;
		}
	}
}

double MapGen::getMoment(int n) const
{
	return	0;
}



// ===================== Gamma =====================
GammaGen::GammaGen(double _alpha, double _beta)
{
	if ( (_alpha<= 0) || (_beta <= 0)){
		cerr<<"Gamma parameter error:\n"; cerr<<_alpha<<" "<<_beta;
		exit(-1);
	}
	alpha=_alpha;
	beta=_beta;
	mean=alpha/beta;
	name="Gamma";	
	cv=1.0/alpha;
	sdv = sqrt(alpha)/beta;
	lambda = 1.0/alpha - 1;
	w = alpha/(exp(1)*(1-alpha));
	r = 1.0/(1.0 + w);
}

GammaGen::GammaGen(char ch, double _k, double _theta)
{
	if (ch!='N') cerr<<"Please specify a way to construct!\n";
	if ( (_k<= 0) || (_theta <= 0)){
		cerr<<"Gamma parameter error:\n"; cerr<<_k<<" "<<_theta;
		exit(-1);
	}
	alpha=_k;

	beta=1/_theta;
	mean=alpha/beta;
	name="Gamma";	
	cv=1/alpha;
	sdv = sqrt(alpha)/beta;
	lambda = 1.0/alpha - 1;
	w = alpha/(exp(1)*(1-alpha));
	r = 1.0/(1.0 + w);
}

double GammaGen::genNext()
{
	double u,z;
	while (1) {
		u = stream.RandU01();
		if (u < r) {
			z = -log(u/r);
		} else {
			z = log(stream.RandU01())/lambda;
		}

		if ((z >= 0) && (exp(-exp(-z/alpha)) > stream.RandU01())) {
			break;
		} else if ((z < 0) && (exp(-z-exp(-z/alpha)-lambda*z)/(lambda*w) > stream.RandU01())) {
			break;
		}
	}

	return exp(-z/alpha)/beta;


}

double GammaGen::getMoment(int n) const
{
	return	0;
}


void GammaGen::restart() {  stream.ResetStartStream(); }

void GammaGen::restartSub() {  stream.ResetStartSubstream(); }

void GammaGen::startNextSub() {  stream.ResetNextSubstream(); }


// ===================== HawkesExpGen =====================
HawkesExpGen::HawkesExpGen(double bg_nu, double alp, double bet) 
{	
	nu = bg_nu;
    lambda_plus = nu + 0.0000001;
	lambda_minus = nu;
	alpha = alp;
	beta = bet;

	D = 0.0;
	S = 0.0;
}

double HawkesExpGen::genNext()
{
	double u = stream.RandU01();
	D = 1 + beta*log(u)/(lambda_plus - nu);

	double u1 = stream.RandU01();
	if (D > 0) {
		S = std::min(-1/beta * log(D), -(1/nu) * log(u1));
	} else {
		S = -(1/nu) * log(u1);
	}
	
	lambda_minus = (lambda_plus-nu) * exp(-beta * S) + nu;
	lambda_plus = lambda_minus + alpha;

	return S;
}

double HawkesExpGen::getMoment(int n) const
{
	return	0;
}



// ===================== XSqGen =====================
XSqGen::XSqGen(double rate) 
{	
	lambda = rate;
}

double XSqGen::genNext()
{
	return sqrt(stream.RandU01())/lambda;
}

double XSqGen::getMoment(int n) const
{
	return	1/lambda;
}