/******************************************************************\
 * File:           Event.h for OQN
 * Language:       C++ (ISO 1998)
 * Copyright:      Wei You, Columbia University
 * Date:           4 April 2014
\******************************************************************/

#ifndef EVENT_H_
#define EVENT_H_

enum EventType {extArrival, intArrival, departure, reneging};

class Event {	

public:
	Event() {};
	Event(double TTM, int loc, EventType tp) {timeToMaturity = TTM; location = loc; type = tp; }
	Event (const Event &e) {timeToMaturity = e.timeToMaturity; location = e.location; type = e.type; customer = e.customer;}
	virtual ~Event(){};

	double timeToMaturity;
	int location;
	EventType type;  
	Customer *customer;

friend class eventCompareT;

};

class eventCompareT
{ 
public : 
	int operator()( Event* x, Event* y )
	{			
		return (x->timeToMaturity > y->timeToMaturity);
	}
	
};

#endif /*EVENT_H_*/
