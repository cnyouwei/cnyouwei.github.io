/******************************************************************\
 * File:           GGN.h for single node queueing system
 * Language:       C++ (ISO 1998)
 * Copyright:      Wei You, Columbia University
 * Date:           4 April 2014
\******************************************************************/

#ifndef GGN_H_
#define GGN_H_

#include "Node.h"
#include "Customer.h"
#include "Event.h"
#include "Rngs.h"

using namespace std;

class GGN {

	public:
	GGN ( ) { };
	GGN (int serverNum, RngBase *arr, RngBase *serv);
	virtual ~GGN ( ) { };
	
	void genArrCust (double arr_time) { arrCust = new Customer(arr_time); }
	Event nextEvent();
	void actOn(Event E);
	
	double getClock()   { return t; }
	double getPrevClock()  { return prevT; }

//get statistic information
	double MeanWaitTime() {return node->getMeanWaitTime(depGuestNum); }

protected:
	
	double t, prevT;  // system clocks
	int numServer; int depGuestNum;

	Customer *arrCust, *depCust;
	Node *node;  

	RngBase *arrGen;

};

#endif
