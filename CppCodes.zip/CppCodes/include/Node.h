/******************************************************************\
 * File:           Node.h for OQN
 * Language:       C++ (ISO 1998)
 * Copyright:      Wei You, Columbia University
 * Date:           4 April 2014
\******************************************************************/

#ifndef Node_H_
#define Node_H_

#include <queue>
#include <list>
#include "Customer.h"
#include "Event.h"
#include "Rngs.h"

using namespace std;

class Node {
public:
	Node () {};
	Node (int ID, int serverNum);
	virtual ~Node () {};

	void initNode (int ID, int serverNum);
	
	double getNextDeparT (); 
	bool checkVacancy() { return ( numInServer < numServer ); }
	bool checkEmpty() { return ( numInServer == 0 ); }
	
	int getNodeID()  { return nodeID; }
	int getNumInServer() { return numInServer; }
	int getNumServer()  { return numServer; }
	int getQueueSize()  { return buffer.size(); }
	int getNumDeparted()  { return numDeparted; }

	void admitCust (double t, Customer *c); 
	void putInQueue ( Customer *c );
	void deptCust ( double t, Customer *c );
	Customer* popNextInQueue (); 

	
	//Statistical information
	void updateWaitTime(double t)  { accuWaitTime += t;}
	double getMeanWaitTime()  { return accuWaitTime/numDeparted; }
	
protected:
	
	int nodeID, numServer, numInServer; 
	int numDeparted;

	list<Customer*> buffer;  //build a buffer using STL list
	
	Customer *nextDepCust;

	//Statistical data
	double accuWaitTime;
};

#endif /*NODE_H_*/