#ifndef BUFFER_H_
#define BUFFER_H_

#include <list>
#include "Customer.h"

class buffer{
public:
	buffer(){};
	virtual ~buffer(){};

	void initBuffer()  { while(!queue.empty()) queue.pop_front(); }

	void inQueue(Customer *c)  { queue.push_back(c); }
	void deQueue( ) { queue.pop_front(); }
	void abandonCust(Customer *c){
		list<Customer *>::iterator it=queue.begin();
		while ( it!=queue.end() )
		{
			if ( (*it)->getTimeToAbd()!= c->getTimeToAbd()  &&  (*it)->getTimeToAbd()!= c->getTimeToAbd() )
				it++;
			else 
				break;
		}
		if ( it==queue.end() )
		{
			printf("Abandon Error!\n");
			exit(-1);
		}
		delete (*it);
		it=queue.erase(it);
//		printf("Customer Abandon!\n");
	}

	Customer *getQueueHead() { return queue.front(); }
	int getQueueSize() { return queue.size(); }
	bool checkEmpty() { return queue.empty(); }


private:
		list<Customer*> queue;  //build a buffer using STL list
};
#endif