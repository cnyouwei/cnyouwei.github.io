/******************************************************************\
 * File:           OQN.h for single node queueing system
 * Language:       C++ (ISO 1998)
 * Copyright:      Wei You, Columbia University
 * Date:           4 April 2014
\******************************************************************/

#ifndef OQN_H_
#define OQN_H_

#include "Node.h"
#include "Customer.h"
#include "Event.h"
#include "Rngs.h"
#include <fstream>
#include <iomanip>
#include <cmath>

using namespace std;

class OQN {

	public:
	OQN ( ) { };
	OQN (int nodesNum, int *serverNum, double **mat, int extArrNum, int *IDextArr, RngBase **arrDist, RngBase **servDist) ;
	virtual ~OQN ( ) { 
		writeArrToLastQ.close();
	};
	
	void genIntArrEvent (int id, double arr_time, Customer *c);
	void genExtArrEvent (int id, double arr_time);
	void genDepartEvent (int id, double serv_start_time, Customer *c);
	void updateWorkload (double simT, int sID, double nextServTime);
	Event nextEvent ();
	void actOn (Event Ev);
	
	double getClock()   { return t; }

//get statistic information
	double MeanWaitTime(int id) {return nodes[id].getMeanWaitTime(); }
	double numDeparted(int id) {return nodes[id].getNumDeparted(); }
	double getAccuWorkload(int id) {return accuWorkload[id];}

protected:
	
	double t;  // system clocks
	int numNodes; 
	Node *nodes;
	double **routingMat;

	int *extArrID; int numExtArr;
	RngBase **extArrGen, **servGen, **routingGen;

	Event *newEv;

	priority_queue<Event*, deque<Event*>, eventCompareT> eventsToCome;  

	// statistical data
	double *workload, *accuWorkload, *lastArrT;
	ofstream writeArrToLastQ;
	double prevT;

};

#endif