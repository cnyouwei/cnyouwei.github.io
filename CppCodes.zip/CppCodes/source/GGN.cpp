/******************************************************************\
 * File:           GGN.cpp for single node queueing system
 * Language:       C++ (ISO 1998)
 * Copyright:      Wei You, Columbia University
 * Date:           4 April 2014
\******************************************************************/

#include "GGN.h"
#include <iostream>

 GGN::GGN (int serverNum, RngBase *arrDist, RngBase *servDist) {
 	
 	t=0; prevT=0; depGuestNum=0;
 	numServer = serverNum;

 	node = new Node(0, numServer, servDist);
 	arrGen = arrDist;

 	// First customer
 	genArrCust( arrGen->genNext() );

 }

void GGN::actOn(Event Ev)
{
	if (t != 0) { prevT = t; }
	t = Ev.timeToMaturity;	

    if (Ev.type == arrival){        // case 1: arrival
		
    	if ( node->checkVacancy() )
			node->admitCust(t, arrCust);
    	else
			node->putInQueue(arrCust);

		genArrCust(arrGen->genNext() + Ev.timeToMaturity);

    } else if (Ev.type == departure) { // case 2: departure at node i, if queue i has customer, then enter node i

    	depGuestNum++;
    	depCust = node->getDepartCust();
		node->deptCust(t);
		delete depCust;

    } else if (Ev.type == reneging){
    	
    } else {
    	cerr<<"something wrong: what is the type of next event?"<<endl;
    } 

}

Event GGN::nextEvent()
{
	Event Ev;
	double nextArrTime;
	double nextDepTime;
	
	nextArrTime = arrCust->getTimeToArr();
	Ev.type = arrival;
	Ev.timeToMaturity = nextArrTime;
	

	if( !node->checkEmpty() ) { 
		nextDepTime = node->getNextDeparT();	
		if (nextDepTime <= nextArrTime) {		
			Ev.type = departure;
			Ev.timeToMaturity = nextDepTime;			
		}
	}

	return Ev;
}

