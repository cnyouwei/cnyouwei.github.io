/******************************************************************\
 * File:           Node.cpp for OQN
 * Language:       C++ (ISO 1998)
 * Copyright:      Wei You, Columbia University
 * Date:           4 April 2014
\******************************************************************/

#include "Node.h"
#include <iostream>

Node::Node (int ID, int serverNum) {
	nodeID = ID; numServer = serverNum; numInServer = 0; 
	numDeparted = 0;

	while(!buffer.empty()) buffer.pop_front();

	accuWaitTime = 0.0;
}

void Node::initNode (int ID, int serverNum) {
	nodeID = ID; numServer = serverNum; numInServer = 0; 
	numDeparted = 0;

	while(!buffer.empty()) buffer.pop_front();

	accuWaitTime = 0.0;
}

void Node::admitCust( double t, Customer *c) {
	c->startService(t, nodeID);
	numInServer++;
	updateWaitTime(c->getWaitTime());	
}

void Node::putInQueue(Customer *c) {
	c->joinQueue(nodeID);
	buffer.push_back(c);   //enter the first buffer
}

void Node::deptCust( double t, Customer *c ) {
	numDeparted++;
	numInServer--;
	c->depart();
	//collect the server-node info
}

Customer* Node::popNextInQueue () {
	Customer *c = buffer.front();
	buffer.pop_front();
	return c;
}


			
