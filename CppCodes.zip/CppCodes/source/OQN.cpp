/******************************************************************\
 * File:           OQN.cpp for single node queueing system
 * Language:       C++ (ISO 1998)
 * Copyright:      Wei You, Columbia University
 * Date:           4 April 2014
\******************************************************************/

#include "OQN.h"
#include <iostream>


 OQN::OQN (int nodesNum, int *serverNum, double **mat, int extArrNum, int *IDextArr, RngBase **arrDist, RngBase **servDist) {
 	
 	t = 0; numNodes = nodesNum; routingMat = mat;

 	nodes = new Node[numNodes];
 	servGen = new RngBase*[numNodes];
 	routingGen = new RngBase*[numNodes];
 	workload = new double[numNodes];
 	accuWorkload = new double[numNodes];
 	lastArrT = new double[numNodes];

 	for (int i = 0; i < numNodes; i++) {
 		nodes[i].initNode(i, serverNum[i]);
 		servGen[i] = servDist[i];
 		routingGen[i] = new DiscreteGen(numNodes,routingMat[i]);
 		workload[i] = 0.0;
 		accuWorkload[i] = 0.0;
 		lastArrT[i] = 0.0;
 	}

	extArrID = IDextArr;  numExtArr = extArrNum;
 	extArrGen = new RngBase*[numExtArr];

 	for (int i = 0; i < numExtArr; i++) {
 		extArrGen[i] = arrDist[i];
 		// Generate first customers
 		genExtArrEvent( extArrID[i], extArrGen[i]->genNext() );
 	}

 	writeArrToLastQ.open("./Data/arrT_GG1.txt");
 	//writeArrToLastQ.open("/Users/WYou/Dropbox/CppCodes/Data/HEHEH_3_arrT.txt");
 	prevT = 0;

 }

void OQN::genIntArrEvent (int id, double arr_time, Customer *c) { 
	newEv = new Event(arr_time, id, intArrival);
	newEv->customer = c;
	eventsToCome.push(newEv);
}

void OQN::genExtArrEvent (int id, double arr_time) {  
	newEv = new Event(arr_time, id, extArrival);
	newEv->customer = new Customer(id);
	eventsToCome.push(newEv);
}

void OQN::genDepartEvent (int id, double serv_start_time, Customer *c) {
	newEv = new Event(serv_start_time + c->getServiceTime(), id, departure);
	newEv->customer = c;
	eventsToCome.push(newEv);
}

void OQN::updateWorkload (double simT, int ID, double nextServTime) {		
	double interArrT = simT - lastArrT[ID];
	//printf("interArrT is: %f. nextServiceT is: %f\n",interArrT, nextServTime);

	if (nodes[ID].checkEmpty()) {
		accuWorkload[ID] = accuWorkload[ID] + workload[ID]*workload[ID]/2;
		workload[ID] = nextServTime;
		//printf("ID is: %d. workload is: %f.  accuWorkload is: %f\n",ID, workload[ID],accuWorkload[ID]);
	} else {
		//printf("ID is: %d. workload is: %f.  accuWorkload is: %f\n",ID, workload[ID],accuWorkload[ID]);
		accuWorkload[ID] = accuWorkload[ID] + workload[ID]*interArrT - interArrT*interArrT/2;
		workload[ID] = workload[ID] - interArrT + nextServTime;
	}

	lastArrT[ID] = simT;
}

void OQN::actOn(Event Ev)
{
	t = Ev.timeToMaturity;	

    if (Ev.type == extArrival || Ev.type == intArrival ){        // case 1: arrival
    	Ev.customer->setArrivalTime(t);
    	double nextServT = servGen[Ev.location]->genNext();
    	//printf("nextServiceT is: %f\n",nextServT);
    	Ev.customer->setServiceTime(nextServT);
    	updateWorkload(t, Ev.location, nextServT);

   		if ( nodes[Ev.location].checkVacancy() ) {
   			nodes[Ev.location].admitCust(t, Ev.customer);
			genDepartEvent(Ev.location,t,Ev.customer);
   		}
    	else {
			nodes[Ev.location].putInQueue(Ev.customer);
    	}

    	if (Ev.type == extArrival) {   // If external, schedule next arrival
    		genExtArrEvent( Ev.location, extArrGen[0]->genNext() + Ev.timeToMaturity);
    	}

    	if (Ev.location == numNodes - 1) {
    		writeArrToLastQ<<std::fixed<<setprecision(8)<<t<<endl;
    		prevT = t;
		}

    } else if (Ev.type == departure) { // case 2: departure

		nodes[Ev.location].deptCust(t,Ev.customer);
		int nextLoc;
		nextLoc = routingGen[Ev.location]->genNext();
		if (nextLoc != -1) {
			genIntArrEvent( nextLoc, t, Ev.customer);
		} else if (nextLoc == -1) {
			delete Ev.customer;
		}

		//If queue is not empty, let the front enter node

		if (nodes[Ev.location].getQueueSize() > 0){
			Customer *c = nodes[Ev.location].popNextInQueue();
   			nodes[Ev.location].admitCust(t, c);
			genDepartEvent(Ev.location,t,c);
		}

    } else if (Ev.type == reneging){
    	
    } else {
    	cerr<<"something wrong: what is the type of next event?"<<endl;
    } 

}

Event OQN::nextEvent()
{
	Event *Eve = eventsToCome.top();
	Event Ev = *Eve;
	eventsToCome.pop();
	delete Eve;
	return Ev;
}

