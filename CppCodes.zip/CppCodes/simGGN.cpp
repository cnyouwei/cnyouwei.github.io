/******************************************************************\
 * File:           simGGN.cpp for simulating single node queueing system
 * Language:       C++ (ISO 1998)
 * Copyright:      Wei You, Columbia University
 * Date:           4 April 2014
\******************************************************************/

#include <fstream>
#include <iostream>
#include <iomanip>
#include <time.h>
#include <tgmath.h>
#include "Rngs.h"
#include "OQN.h"

using namespace std;

int main()
{
	//int i,j,k;
	double simTime;    // length of one run
	//int numRuns = 1;         // number of runs	
	int startTime = time(NULL);

	int numNodes = 1;
	int *numServer = new int[numNodes];
	for(int i = 0; i < numNodes; i++ ) {numServer[i] = 1;}

	RngBase **arr, **serv;

	arr = new RngBase*[numNodes];
	int extArrID[1] = {0};
	int numExtArr = 1;
	serv = new RngBase*[numNodes];

	double **mat = new double*[numNodes];
	
	for (int i = 0; i < numNodes; i++) {
		mat[i] = new double[numNodes];
		for (int j = 0; j < numNodes; j++) {
			mat[i][j] = 0;
		}
	}	

	for (int i = 0; i < numNodes-1; i++) {
		mat[i][i+1] = 1;
	}




	/*   ------ Set RV parameters -----  */
		
		/*   ------ H2 parameters -----  */
	double SCV_H2 = 2;
	double p_H2 = (1 - sqrt((SCV_H2 - 1)/(SCV_H2 + 1)))/2;
	double mu1_H2 = 2*p_H2;		
	double mu2_H2 = 2*(1-p_H2);

	/*double SCV2_H2 = 10;
	double p2_H2 = (1 - sqrt((SCV2_H2 - 1)/(SCV2_H2 + 1)))/2;
	double mu12_H2 = 2*p2_H2;		
	double mu22_H2 = 2*(1-p2_H2);*/
		/*   --------------------------  */

	/*   ------------------------------  */


	for (double rho = 0.67; rho < 1; rho += 0.01) {
		
		/*   ------ Set Arrivals and Services -----  */

		//int num_stream = 100;
		//arr[0] = new SuperpositionGen(num_stream, new HyperExp2Gen(mu1_H2/num_stream,mu2_H2/num_stream,p_H2));
		//arr[0] = new HyperExp2Gen(mu1_H2,mu2_H2,p_H2);
		arr[0] = new DetGen(1.0/rho);
		serv[0] = new ExpGen(1.0);

		/*arr[0] = new ErlangGen(10,10);

		serv[0] = new HyperExp2Gen(mu1_H2/0.99,mu2_H2/0.99,p_H2);
		serv[1] = new ErlangGen(10/0.98,10);
		serv[2] = new HyperExp2Gen(mu12_H2/0.7,mu22_H2/0.7,p2_H2);
		serv[3] = new ErlangGen(10/0.5,10);
		serv[4] = new ExpGen(1.0/rho);*/
		
		/*arr[0] = new ErlangGen(2,2);

		serv[0] = new ExpGen(1.0/rho);
		serv[1] = new ErlangGen(10/0.99,10);
		serv[2] = new ErlangGen(10/0.99,10);
		serv[3] = new HyperExp2Gen(mu1_H2/0.92,mu2_H2/0.92,p_H2);
		serv[4] = new HyperExp2Gen(mu1_H2/0.92,mu2_H2/0.92,p_H2);
		serv[5] = new HyperExp2Gen(mu1_H2/0.92,mu2_H2/0.92,p_H2);
		serv[6] = new ErlangGen(10/0.90,10);
		serv[7] = new ErlangGen(10/0.90,10);
		serv[8] = new ErlangGen(10/0.90,10);
		serv[9] = new HyperExp2Gen(mu12_H2/0.30,mu22_H2/0.30,p2_H2);
		serv[10] = new HyperExp2Gen(mu12_H2/0.30,mu22_H2/0.30,p2_H2);
		serv[11] = new HyperExp2Gen(mu12_H2/0.30,mu22_H2/0.30,p2_H2);
		serv[12] = new ExpGen(1.0/rho);*/
		
		/*arr[0] = new HyperExp2Gen(mu12_H2,mu22_H2,p2_H2);

		serv[0] = new DetGen(0.6);
		serv[1] = new DetGen(0.6);
		serv[2] = new DetGen(0.6);
		serv[3] = new DetGen(0.6);
		serv[4] = new DetGen(0.6);
		serv[5] = new DetGen(0.6);
		serv[6] = new DetGen(0.6);
		serv[7] = new DetGen(0.6);
		serv[8] = new DetGen(0.95);
		serv[9] = new ExpGen(1.0/rho);*/

		/*   ------ Start Simulation  -----  */

		OQN myQueue(numNodes,numServer,mat,numExtArr,extArrID,arr,serv);

		Event event;

		simTime = 10000000;

		while(myQueue.getClock() < simTime){
			event = myQueue.nextEvent ( );
			myQueue.actOn(event);
		}

		/*ofstream writeWorkload;
		writeWorkload.open("./Data/WL_Sup100.txt",ios::app);	
		ofstream writeWaitTime;
		writeWaitTime.open("./Data/WT_Sup100.txt",ios::app);*/
		

		//printf("%f \t %f\n",rho, myQueue.MeanWaitTime(numNodes-1)*2*(1-rho)/(rho*rho));
		double normalizedWL = (myQueue.getAccuWorkload(numNodes-1)/(simTime))*2*(1-rho)/(rho*rho);
		double normalizedWT = myQueue.MeanWaitTime(numNodes-1);//*2*(1-rho)/(rho*rho);
		//writeWorkload<<rho<<"\t"<<normalizedWL<<"\n";
		//writeWaitTime<<rho<<"\t"<<normalizedWT<<"\n";

		printf("%1.3f \t %1.3f \t %1.3f",rho, normalizedWL,normalizedWT);
		int endTime = time(NULL);
		cout<<"\t CPU time: "<<(endTime-startTime)/60<<" min "<<(endTime-startTime)%60<<" seconds."<<endl;

		//writeWorkload.close();
		//writeWaitTime.close();
	}

	
	/*   ------ End Simulation  -----  */	

	printf("-----------------------End Simulation------------------------\n");

	//int endTime = time(NULL);
	//cout<<"CPU time: "<<(endTime-startTime)/60<<" min "<<(endTime-startTime)%60<<" seconds.\n"<<endl;

	return 0;
}
